<?php 

$tipoProfissional = $_POST["tipoProfissional"];
$cep = $_POST["cep"];


?>
<p class="text-center">
	Nada foi encontrado
</p>