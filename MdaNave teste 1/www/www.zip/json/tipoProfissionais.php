<?php 
// AQUI A TELA DE CARREGAMENTO
?>
[
    { label: 'C++', value: 'C++' }, 
    { label: 'Java', value: 'Java' }
    { label: 'COBOL', value: 'COBOL' }
]