<!-- GOOGLE MAPS -->
<div id="GoogleMapa"></div>
<!-- GOOGLE MAPS -->



<div class="container" style="padding-bottom:65px;">

     <div class="row">

         <div class="col-sm-12 col-xs-12 text-left user-preview">         
	             <h5>Nome do profissional</h5>
	             <span>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star-half-o" aria-hidden="true"></i>
	             </span>
	             <p>Rua Ricardo Pedro, 56 <br>São Paulo - SP<br>
	             <i class="fa fa-phone" aria-hidden="true"></i> 0000-0000&nbsp;             
	             </p>
	             <p class="btn-detalhe"><a href="detalhes-user.php" class="btn btn-primary">DETALHES</a></p>
         </div>
         <div class="col-sm-12 col-xs-12 text-left user-preview">         
	             <h5>Nome do profissional</h5>
	             <span>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star-half-o" aria-hidden="true"></i>
	             </span>
	             <p>Rua Ricardo Pedro, 56 <br>São Paulo - SP<br>
	             <i class="fa fa-phone" aria-hidden="true"></i> 0000-0000&nbsp;             
	             </p>
	             <p class="btn-detalhe"><a href="detalhes-user.php" class="btn btn-primary">DETALHES</a></p>
         </div>
         <div class="col-sm-12 col-xs-12 text-left user-preview">         
	             <h5>Nome do profissional</h5>
	             <span>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star-half-o" aria-hidden="true"></i>
	             </span>
	             <p>Rua Ricardo Pedro, 56 <br>São Paulo - SP<br>
	             <i class="fa fa-phone" aria-hidden="true"></i> 0000-0000&nbsp;             
	             </p>
	             <p class="btn-detalhe"><a href="detalhes-user.php" class="btn btn-primary">DETALHES</a></p>
         </div>

         <div class="col-sm-12 col-xs-12 text-center user-preview" id="areaBannerAnuncio1">
             <a href="#">
                 <img src="http://www.csprofissionais.com.br/upload/11072016234342Anu1.png" />
             </a>
         </div>

         <div class="col-sm-12 col-xs-12 text-left user-preview">         
	             <h5>Nome do profissional</h5>
	             <span>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star-half-o" aria-hidden="true"></i>
	             </span>
	             <p>Rua Ricardo Pedro, 56 <br>São Paulo - SP<br>
	             <i class="fa fa-phone" aria-hidden="true"></i> 0000-0000&nbsp;             
	             </p>
	             <p class="btn-detalhe"><a href="detalhes-user.php" class="btn btn-primary">DETALHES</a></p>
         </div>

         <div class="col-sm-12 col-xs-12 text-center user-preview" id="areaBannerAnuncio2">
             <a href="#">
                 <img src="http://www.csprofissionais.com.br/upload/11072016234342Anu1.png" />
             </a>
         </div>

         <div class="col-sm-12 col-xs-12 text-left user-preview">         
	             <h5>Nome do profissional</h5>
	             <span>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star" aria-hidden="true"></i>
		             <i class="fa fa-star-half-o" aria-hidden="true"></i>
	             </span>
	             <p>Rua Ricardo Pedro, 56 <br>São Paulo - SP<br>
	             <i class="fa fa-phone" aria-hidden="true"></i> 0000-0000&nbsp;             
	             </p>
	             <p class="btn-detalhe"><a href="detalhes-user.php" class="btn btn-primary">DETALHES</a></p>
         </div>

         <div class="col-sm-12 col-xs-12 text-center user-preview" id="areaBannerAnuncio3">
             <a href="#">
                 <img src="http://www.csprofissionais.com.br/upload/11072016234342Anu1.png" />
             </a>
         </div>

     </div>



</div>
<!-- WORK -->